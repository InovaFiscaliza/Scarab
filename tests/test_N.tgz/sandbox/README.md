## Procedimento de teste – novo fluxo `scarab::SCH`

### 1) Configuração inicial

Descompactar e carregar o conteúdo dos arquivos listados abaixo na pasta **POST** do `monitorRNI`:

* **Arquivo 1** – `Arquivo 1 - SCH_FinalReport_2026.02.13_T10.05.40_10097.zip`
* **Arquivo 2** – `Arquivo 2 - SCH_FinalReport_2026.02.13_T10.16.06_10098.zip`

### 2) Processamento esperado

O `scarab` deve consolidar as informações e gerar um arquivo Excel contendo as seguintes abas:

1. **PUBLICAÇÃO**

   * Planilha “coringa” composta pelas chaves da raiz do arquivo JSON que não serão consolidadas em outra aba, além da coluna "correlationKey", cujo valor é extraído do nome do arquivo.
   * Não há exclusão de informação, apenas inclusão.

2. **PROJETO**

   * Consolidação do objeto `project`.
   * Planilha “mãe”, cuja chave primária é a concatenação das colunas:
     `system`, `issue`, `context`, `entityGroupName`, `entityGroupId` e `unit`.
   * Análise da unicidade dessa chave determina o que será incluído ou excluído nas demais abas (exceto **PUBLICAÇÃO**).

3. **PRODUTOS**

   * Consolidação do objeto `inspectedProducts`.

De forma paralela, os servidores **Eric** e **Lobão** devem receber notificações via Microsoft Teams.

---

### 3) Cenário de retificação

Após a consolidação inicial, descompactar e carregar o conteúdo do arquivo abaixo na pasta **POST** do `monitorRNI`:

* **Arquivo 3** – `Arquivo 3 - SCH_FinalReport_2026.02.13_T10.19.33_10098 (RETIFICAÇÃO)`

### 4) Comportamento esperado para a retificação

* As informações do arquivo são incluídas na aba **PUBLICAÇÃO**.
* Na aba **PROJETO**, o scarab identifica que se trata de informação já existente na base. Consequentemente, em todas as abas (exceto **PUBLICAÇÃO**):

  * remove os registros associados ao `oldCorrelationKey`;
  * inclui os novos registros associados ao `newCorrelationKey`.

De forma paralela, o servidor **Eric** deve receber notificação via Microsoft Teams.
